# Nexus-Virtual-Assistant
Nexus is a Windows-based virtual assistant.I t executes tasks via voice commands or keyboard input. , streamlining everyday computing for improved productivity and convenience.
